<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "kontrakan";

$konek = mysqli_connect($host, $user, $pass, $db) or die("Database MYSQL Tidak Terhubung");