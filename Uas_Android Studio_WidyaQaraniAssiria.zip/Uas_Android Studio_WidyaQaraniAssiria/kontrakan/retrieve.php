<?php
require("konek.php");
$perintah = "SELECT * FROM data_kontrakan";
$eksekusi = mysqli_query($konek, $perintah);
$cek = mysqli_affected_rows($konek);

if($cek > 0){
    $response["kode"] = 1;
    $response["pesan"] = "Data Tersedia";
    $response["data"] = array();

    while($ambil = mysqli_fetch_object($eksekusi)){
        $F["Id"] = $ambil->Id;
        $F["Nama"] = $ambil->Nama;
        $F["JK"] = $ambil->JK;
        $F["Alamat"] = $ambil->Alamat;
        $F["NoTelepon"] = $ambil->NoTelepon;

        array_push($response["data"], $F);
    }
}
else{
    $response["kode"] = 0;
    $response["pesan"] = "Data Tidak Tersedia";
}

echo json_encode($response);
mysqli_close($konek);